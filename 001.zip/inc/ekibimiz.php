    <section class="team_section">
      <div class="container">
        <div class="row">
          <div class="col-md-12"> 
            <div class="team_main">
              <div class="team_section_shape">
                <img src="assets/images/icon/team-section-shape.svg" class="img-fluid" alt="">
              </div> 
              <div class="common_heading">
                <div class="title_style">
                  <span></span><h3>Uzmanımız</h3>
                </div>
                <h2>Uzmanımızı Tanıtalım <br> <span> Ekip Üyemiz</span> </h2>
               </div>
               <div class="team_carousel owl-carousel">
<?php
            $cek = $db->query("select * from ekibimiz where durum='0' order by sira asc")->fetchAll(PDO::FETCH_ASSOC);
            foreach ($cek as $goster) {
            ?>
                <div class="team_member">
                  <img src="resimler/<?=$goster["resim"]?>" class="img-fluid" alt="">
                <div class="member_info">
                  <div class="member_info_wrapper">
                    <p><?=$goster["onaciklama"]?><span></span></p>
                    <h5><?=$goster["adi"]?></h5>
                      

                  </div>
                </div>
                </div>
                
      <?php } ?>
              </div>
            </div>
           
          </div>
        </div>
        
      </div>
    </section>
