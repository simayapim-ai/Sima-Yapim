    <section class="customer_review_section">
            <div class="container">
                <div class="col-md-12">
                    <div class="customer_review_main">
                        <div class="common_heading">
                            <div class="title_style">
                              <span></span><h3>Mutlu Müşterilerimiz</h3>
                            </div>
                            <h2>Müşteri Yorumları ve <br> <span> Bize Bakış Açıları</span> </h2>
                           </div>
                           <div class="review_carousel owl-carousel">
                            <?php
                            $cek = $db->query("select * from yorumlar where durum='0' order by sira asc")->fetchAll(PDO::FETCH_ASSOC);
                            foreach ($cek as $goster) {
                            ?>
                            <div class="review_item">
                                <div class="review_author">
                                    <div class="review_author_line">
                                        <img src="resimler/<?=$goster["resim"]?>" class="img-fluid" alt="">
                                    </div>
                                </div>
                                <h4><?= $goster["adi"] ?></h4>
                                <span><?= $goster["onaciklama"] ?></span>
                                <p><?= $goster["aciklama"] ?></p>
                               <div class="review_quote ">
                                <img src="assets/images/icon/quote-red.svg" class="img-fluid" alt="">
                               </div>
                            </div>
                            <?php } ?>
                           </div>
                    </div>
                </div>
            </div>
    </section>
