  <section class="great_service_section">
    <div class="common_heading text-center">
        <div class="title_style">
          <span></span><h3>Hizmetler</h3>
        </div>
        <h2> En Son Yaptığımız Hizmetler İnceleyelim <br> <span> Biten Projemiz</span> </h2>
       </div>

       <div class="container">
        <div class="row gy-4">
          <?php
            $cek = $db->query("select * from hizmetler where durum='0' order by sira asc")->fetchAll(PDO::FETCH_ASSOC);
            foreach ($cek as $goster) {
            ?>
          <div class="col-md-6 col-lg-4">
            <div class="service_page_item">
              <img src="resimler/<?=$goster["resim"]?>" class="img-fluid service_image" alt="">
              <img src="assets/images/bg/service-page-item-hover-shape.png" class="img-fluid service_page_shape1" alt="">
              <img src="assets/images/bg/service-page-item-shape.png" class="img-fluid service_page_shape2" alt="">
              <div class="service_page_item_wrapper">
                <div class="service_page_item_top">
                  <h4><?=$goster["adi"]?></h4>
                  
              </div>
              <p><?=$goster["onaciklama"]?></p>
              <div class="service_page_item_bottom">
                  <a href="<?=$goster["seo"]?>" class="common_btn" >Devamını Oku <i class="ensurx-arrow-right"></i></a>
                  <img src="resimler/<?=$goster["icon"]?>" class="img-fluid" alt="">
              </div>
              </div>
            </div>
          </div>
          <?php }?>
        </div>
       </div>
</section>
