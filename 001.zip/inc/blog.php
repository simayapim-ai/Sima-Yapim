       <section class="blog_section">
        <div class="container">
          <div class="blog_main">
            <div class="common_heading text-center">
              <div class="title_style">
                <span></span><h3>Blog ve haberler</h3>
              </div>
              <h2> En Yenilerden Haberdar Olun <br> <span> Blog Yazıları ve Haberler</span> </h2>
             </div>
            <div class="row gy-4">
              <?php
            $cek = $db->query("select * from haberler where durum='0' order by sira asc")->fetchAll(PDO::FETCH_ASSOC);
            foreach ($cek as $goster) {
            ?>
              <div class="col-sm-12 col-md-6 col-lg-4">
                <div class="blog_item">
  
                  <div class="blog_top">
                    <img src="resimler/<?=$goster["resim"]?>" class="img-fluid" alt="">
                  </div>
                  
                  <div class="blog_content">
                    <h3> <a href="<?=$goster["seo"]?>"><?=$goster["adi"]?></a> </h3>
                    <p><?=$goster["onaciklama"]?></p>
                    <a href="<?=$goster["seo"]?>" class="blog_btn">Devamını Oku <i class="ensurx-arrow-right"></i></a>
                  </div>
  
  
                </div>
              </div>
              <?php } ?>
            </div>
          </div>
        </div>
      </section>
