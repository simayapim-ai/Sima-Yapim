    <section class="about_company_section">
      <div class="container">
          <div class="row align-items-center">
              <div class="col-md-12 col-lg-5">
                  <div class="company_left_wrapper">
                      <div class="company_separate_left">
                          <img src="assets/images/img/about-company-left-top.png" class="img-fluid ms-3" alt="">
                          <img src="assets/images/img/about-company-left-bottom.png" class="img-fluid" alt="">
                      </div>
                      <div class="company_left_middle text-center">
                          <h2><span class="counter">30</span><span>+</span></h2>
                          <p>Yılların<br> Deneyimi</p>
                      </div>
                      <div class="company_separate_right">
                          <img src="assets/images/img/about-company-shape.png" class="img-fluid me-5" alt="">
                          <img src="assets/images/img/about-company-left-right.png" class="img-fluid" alt="">
                      </div>

                  </div>
              </div>
              <div class="col-md-12 col-lg-7 mt-5">
                  <div class="company_right_main">
                      <div class="common_heading">
                          <div class="title_style">
                            <span></span><h3>Hakkimizda</h3>
                          </div>
                          <h2><?=$hakkimizda["adi"]?></h2>
                      </div>
                      <p><?=$hakkimizda["aciklama"]?></p>
                      <div class="hero_left_buttons">
                <a href="hakkimizda" class="common_btn btn">Devamını Oku</a>
              </div>
                  </div>
                   
              </div>
          </div>
      </div>
  </section>
