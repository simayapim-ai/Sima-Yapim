<?php
include("admin/include/baglan.php");
include("admin/include/fonksiyonlar.php");
?>
<!doctype html>
<html lang="tr">
  <head>
    <!-- ======= (REQUIRED META TAGS) ======= -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- ======= (SITE TITLE) ======= -->
    <title><?=$title?></title>

    <!-- ======= (SITE ICON) ======= -->
    <link rel="icon" href="resimler/<?=$favicon?>">

    <!-- ======= (BOOTSTRAP CSS FILE) ======= -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">

    <!-- ======= (GOOGLE FONT CSS FILE) ======= -->
    <link rel="stylesheet" href="assets/css/google.font.css">

    <!-- ======= (ICONLY ICON FILE) ======= -->
    <link rel="stylesheet" href="assets/ensurx-font/iconly.min.css">
    
    <!-- ======= (OWL CAROUSEL CSS) ======= -->
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/owl.theme.default.min.css">

    <!-- ======= (CUSTOM CSS FILE) ======= -->
    <link rel="stylesheet" href="assets/css/style.css">

    <!-- ======= (CUSTOM RESPONSIVE CSS) ======= -->
    <link rel="stylesheet" href="assets/css/media.css">
  </head>

  <body>
  
    

<?php
        include("inc/header.php");
        include("inc/slider.php");
        include("inc/hakkimizda.php");
        include("inc/projeler.php");
        include("inc/hizmetler.php");
        include("inc/ekibimiz.php");
        include("inc/referanslar.php");
        include("inc/sss.php");
        include("inc/yorum.php");
        include("inc/blog.php");
        include("inc/footer.php");
        
		
		?>
<!-- ======= ( FOOTER SECTION START ) ======= -->
<!-- ======= ( FOOTER SECTION END ) ======= -->



  
    <!-- ======= (JQUERY CDN FILE) ======= -->
    <script src="assets/js/jquery-1.12.4.min.js"></script>

    <!-- ======= (BOOTSTRAP JS FLIE) ======= -->
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    
    <!-- ======= (OWL CAROUSEL JS FILE) ======= -->
    <script src="assets/js/owl.carousel.min.js"></script>

    <!-- ======= (CUSTOM JS FILE) ======= -->
    <script defer src="assets/js/script.js"></script>

    <!-- ======= (COUNTER UP JS) ======= -->
    <script src="assets/js/jquery.waypoints.min.js"></script>
    <script  src="assets/js/jquery.counterup.min.js"></script>

    <!-- ======= (MIXITUP JS FILE) ======= -->
    <script src="assets/js/mixitup.min.js"></script>
    
  </body>
</html>