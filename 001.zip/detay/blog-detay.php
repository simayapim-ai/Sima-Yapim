<section class="blog_details_section">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-lg-8">
                   <div class="blog_details_left">
                    <div class="row">
                        <div class="col-md-12 mb-5">
                            <img src="resimler/<?=$haberler["resim"]?>" class="img-fluid" alt="">
                            <h2 class="mb-5 mt-5"><?=$haberler["adi"]?></h2>
                            <p class="mt-5"><?=$haberler["aciklama"]?></p>
                        </div>
                        
                    </div>
                   </div>
                </div>
                                <div class="col-md-12 col-lg-4">
                   <div class="blog_sidebar">
                    <div class="row gy-5">
                        <div class="col-md-12">
                            <div class="blog_page_post">
                                <h3>Popüler Gönderiler</h3>
                                <?php
                        $cek = $db->query("select * from haberler where durum='0' order by sira asc")->fetchAll(PDO::FETCH_ASSOC);
						foreach($cek as $goster){
						?>
                                <div class="post_item_wrapper">
                                        <img src="resimler/<?=$goster["resim"]?>" class="img-fluid" alt="">
                                    <div class="post_content">
                                        <a href="<?=$goster["seo"]?>"><?=$goster["adi"]?></a>
                                        <span><?=$goster["eklenme_tarihi"]?></span>
                                    </div>
                                </div>
                                <?php }?> 
                            </div>
                        </div>
                        
                    </div>
                   </div>
                </div>

            </div>
        </div>
    </section>