      <div class="hero_nav_main">
        <nav class="navbar navbar-expand-lg">
          <div class="container">
            <a class="navbar-brand" href="index.php"><img src="resimler/<?=$logo?>" width="95" height="43"class="img-responsive" alt=""></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse align-items-center" id="navbarSupportedContent">
              <ul class="navbar-nav m-auto">
                <li class="nav-item">
                  <a class="nav-link active" href="index.php">Anasayfa</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="hakkimizda">Hakkımızda</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="hizmetler">Hizmetler</a>
                </li> 
                <li class="nav-item">
                  <a class="nav-link" href="projeler">Projeler</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="referanslarimizdan-bazilari">Referanslar</a>
                    </li>
                <li class="nav-item">
                  <a class="nav-link" href="blog">Haberler</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="iletisim">İletişim</a>
                    </li>
                <li class="nav-item">
                  <a class="nav-link active" href="https://simayapim.com/katalog/">Katalog</a>
                </li>
                    </li>
                <li class="nav-item">
                  <a class="nav-link active" href="https://magaza.simayapim.com/">Online Mağaza</a>
                </li>
              </ul>
            </div>
          </div>
        </nav>
      </div>
