<footer>

  <section class="call_action_section">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="call_action_main">
            <div class="call_action_left">
              <h3>Her zaman buradayız !</h3>
              <p>Sima Yapım olarak bir telefon kadar yakınınızdayız.</p>
              <a href="iletisim" class="common_btn">İletişim <i class="ensurx-arrow-right"></i></a>
              </div>
  
              <div class="call_action_right">
                <img src="assets/images/img/call-to-action.png" class="img-fluid" alt="">
              </div>
              <div class="call_action_shadow">
                <img src="assets/images/bg/call-to-action-shadow.png" class="img-fluid" alt="">
              </div>
              <div class="call_action_shape">
                <img src="assets/images/bg/call-to-action-shape.png" class="img-fluid" alt="">
              </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <div class="footer_section">
    <div class="container">
      <div class="row gy-5">
        <div class="col-md-3 col-sm-6">
          <div class="footer_first">
            <img src="resimler/<?=$footerlogo?>" class="img-fluid" alt="">
            <p><?=$hakkimizda["footer"]?></p>
            <ul>
              <li><a href="<?=$facebook?>"><i class="ensurx-facebook-solid"></i></a></li>
              <li><a href="<?=$twitter?>"><i class="ensurx-x-twitter"></i></a></li>
              <li><a href="<?=$linkedin?>"><i class="ensurx-linkedin-solid"></i></a></li>
              <li><a href="<?=$instagram?>"><i class="ensurx-instagram"></i></a></li>
            </ul>
          </div>
        </div>
        <div class="col-md-3 col-sm-6">
          <div class="footer_explore">
              <div class="title_style">
                <h3>Menü</h3>  <span></span>
              </div>
              <ul>
                <?php
            $cek = $db->query("select * from menu where durum='0' order by sira asc limit 5")->fetchAll(PDO::FETCH_ASSOC);
            foreach ($cek as $goster) {
            ?>
                <li><a href="<?=$goster["url"]?>"><?=$goster["adi"]?></a></li>
               <?php } ?>
              </ul>
            
          </div>
        </div>
        <div class="col-md-3 col-sm-6">
          <div class="footer_explore">
              <div class="title_style">
                <h3>Hizmetler</h3>  <span></span>
              </div>
              <ul>
                <?php
            $cek = $db->query("select * from hizmetler where durum='0' order by sira asc limit 5")->fetchAll(PDO::FETCH_ASSOC);
            foreach ($cek as $goster) {
            ?>
                <li><a href="<?=$goster["seo"]?>"><?=$goster["adi"]?></a></li>
               <?php } ?>
              </ul>
            
          </div>
        </div>
        <div class="col-md-3 col-sm-6">
          <div class="footer_contact">
              <div class="title_style">
                <h3>İletişim</h3>  <span></span>
              </div>
             <div class="footer_contact_wrapper">
              <i class="ensurx-footer-map"></i>
              <div class="footer_contact_info">
                <a href=""><?=$adres1?></a>
              </div>
              </div>
                           </div>

             <div class="footer_contact_wrapper">
              <i class="ensurx-footer-map"></i>
              <div class="footer_contact_info">
                <a href=""><?=$adres2?></a>
             </div>
                          </div>

             <div class="footer_contact_wrapper">
              <i class="ensurx-footer-call"></i>
              <div class="footer_contact_info">
                <a href="tel:"><?=$telefon1?></a>
                <a href="tel:"><?=$telefon2?></a>
              </div>
             </div>
             </div>
            
          </div>
        </div>
        
      </div>
    </div>
  </div>

  <div class="footer_bottom">
    <div class="container">
      <div class="row">
          <div class="col-md-12">
              <p><?=$copyright?></p>
          </div>
      </div>
    </div>
  </div>
  
</footer>
