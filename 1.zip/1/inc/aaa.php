    <section class="faq_section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="faq_main">
                        <img src="assets/images/img/fag.png" class="img-fluid" alt="">
                        <a href="iletisim">
                            <div class="faq_msg">
                                <img src="assets/images/icon/faq-msg.svg" class="img-fluid" alt="">
                            </div>
                             Daha Fazla Sorunuz Varsa<span> Bize Ulaşın..</span></a>
                    </div>
                </div>
            </div>
        </div>
        <div class="faq_content_main">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-lg-8 ms-auto">
                        <div class="faq_right_content ">
                          <div class="row gy-4 accordion" id="accordionExample">
<?php
                        $cek = $db->query("SELECT * FROM sss WHERE durum='0' ORDER BY sira ASC")->fetchAll(PDO::FETCH_ASSOC);
                        foreach($cek as $key => $goster){
                            $collapseId = 'collapse_'.$key; 
                        ?>
                            <div class="col-md-12"> 
    <div class="accordion-item">
        <h2 class="accordion-header">
            <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#<?=$collapseId?>" aria-expanded="false" aria-controls="<?=$collapseId?>">
                <?=$goster["adi"]?>
            </button>
        </h2>
        <div id="<?=$collapseId?>" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
            <div class="accordion-body">
                <p><?=$goster["aciklama"]?></p>
            </div>
        </div>
    </div>
</div>

                            <?php }?>
                         </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
