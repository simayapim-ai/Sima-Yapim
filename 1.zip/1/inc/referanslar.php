     <section class="client_section">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="owl-carousel client_carousel">
  <?php
            $cek = $db->query("select * from referanslar where durum='0' order by sira asc")->fetchAll(PDO::FETCH_ASSOC);
            foreach ($cek as $goster) {
            ?>
                <div class="client_item">
                  <img src="resimler/<?=$goster["resim"]?>" class="img-fluid" alt="">
                </div>
                
              <?php } ?>
              </div>
            </div>
          </div>
        </div>
      </section>
