      <?php
                                    $slider = $db->query("select * from slider where durum='0' order by id desc")->fetch(PDO::FETCH_ASSOC);
									?>
      <div class="hero_main">
        <div class="container">
        <img src="assets/images/bg/hero-shape2.png" class="img-fluid hero_shape2" alt="">
        <img src="assets/images/bg/hero-icon-right.png" class="img-fluid hero_icon_right" alt="">
        <img src="assets/images/bg/hero-icon-left.png" class="img-fluid hero_icon_left" alt="">
          <div class="row banner_reverse align-items-center">
            <div class="col-md-6">
              <div class="hero_left">
                <div class="common_heading">
                  <div class="title_style ">
                    <span></span><h3><?=$title?></h3>
                  </div>
                  <h1><?=$slider["adi"]?></h1>
              </div>
              <p><?=$slider["aciklama"]?></p>
              <div class="hero_left_buttons">
                <a href="<?=$slider["linki"]?>" class="common_btn btn">İnceleyin</a>
              </div>

              <!-- Modal -->
              <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"  aria-hidden="true">
                <div class="modal-dialog modal-dialog modal-dialog-centered">
                  <div class="modal-content">
                    <div class="modal-header">
                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                      <iframe src="https://www.youtube.com/embed/txzZiC2PQas?si=ry0aTh8KvZVYJG9" title="YouTube video player" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
                    </div>
                  </div>
                </div>
              </div>
              <!-- modal -->
              </div>
            </div>
            <div class="col-md-6">
              <div class="hero_right">
                <div class="hero_banner">
                  <img src="resimler/<?=$slider["resim"]?>" class="img-fluid" alt="">
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
