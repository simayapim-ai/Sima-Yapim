<div class="mechanics_section_wrapper">
        
      <!-- ======= (FINISHED PROJECT SECTION START) ======= -->
      <section class="finished_project_section">
        <div class="container">
          <div class="common_heading text-center">
            <div class="title_style">
              <span></span><h3 class="text-white">Projelerimiz</h3>
            </div>
            <h2 class="text-white">  En İyiyi Hayal Ediyor <br> <span>En İyisini Üretiyoruz ! </span> </h2>
           </div>
          <div class="  owl-carousel finished_projects_carousel">
            <?php
            $cek = $db->query("select * from projeler where durum='0' order by sira asc")->fetchAll(PDO::FETCH_ASSOC);
            foreach ($cek as $goster) {
            ?>
            <div class="finished_item">
              <img src="resimler/<?=$goster["resim"]?>" class="img-fluid" alt="">
              <div class="turm_and_ploicy">
                <div class="turm_and_ploicy_wrapper">
                <h4><?= $goster["adi"] ?></h4>
                <div class="ploicy_arrow">
                  <a href="<?= $goster["seo"] ?>"> <i class="ensurx-arrow-right"></i> </a>
                </div>
                </div>
              </div>
            </div>
            <?php } ?>
          </div>
        </div>
      </section>
     
      <!-- ======= (FINISHED PROJECT SECTION END) ======= -->

      <section class="mechanics_section">
          <div class="container">
              <div class="row gy-5 justify-content-around">
                  <?php
                     $cek = $db->query("select * from ozellik where durum='0' order by sira asc limit 3")->fetchAll(PDO::FETCH_ASSOC);
                     foreach($cek as $goster){
                     ?>
                  <div class="col-md-6 col-lg-4">
                      <div class="mechanics_item">
                          <div class="mechanics_icon_wrapper">
                             <div class="mechanics_icon">
                              <img src="resimler/<?=$goster["resim"]?>" class="img-fluid" alt="">
                             </div>
                          </div>
                          <h4><?=$goster["adi"]?></h4>
                          <p><?=$goster["aciklama"]?></p>
                      </div>
                  </div>
                 <?php } ?>
              </div>
          </div>
      </section>

</div>