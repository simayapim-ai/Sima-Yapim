<div class="contact_page_wrapper">

        <section class="contact_page_main">
          <div class="container">
            <div class="row">
              <div class="col-md-12 col-lg-6">
                <div class="contact_page_left">
                  <h2>İletişime Geçin</h2>
                  <p>Sima Yapım her zaman sizler için burada..</p>

                  <div class="contact_info_wrapper">
                    <i class="ensurx-footer-map"></i>
                    <div class="contact_page_info">
                      <a href="#"><?=$adres1?><br><br> <?=$adres2?></a>
                      <span>Adres</span>
                    </div>
                   </div>
                   <div class="contact_info_wrapper">
                    <i class="ensurx-footer-call"></i>
                    <div class="contact_page_info">
                      <a href="tel:"><?=$telefon1?></a>
                      <a href="tel:"><?=$telefon2?></a>
                      <span>Telefon numarası</span>
                    </div>
                   </div>
                   <div class="contact_info_wrapper">
                    <i class="ensurx-footer-mail"></i>
                    <div class="contact_page_info">
                      <a href="mailto:"><?=$email1?></a>
                      <a href="mailto:"><?=$email2?></a>
                      <span>E-mail Adres</span>
                    </div>
                   </div>

                </div>
              </div>
              <div class="col-md-12 col-lg-6">
                <div class="contact_page_right_wrapper">
                  <div class="contact_page_right">
                    <form class="row " action="admin/include/fonksiyonlar.php" method="post">
                        <input type="hidden" name="link" value="../../iletisim">
                      <div class="col-md-12">
                        <h2>İstek Öneri ve Değerli Yorumlarınız İçin</h2>
                        <p>BİZE MESAJ ATIN</p>
                      </div>
                      <div class="col-md-6">
                        <div class="input_feild">
                          <input type="text" class="form-control name" name="adsoyad" placeholder="Ad Soyad">
                          <div class="icon">
                            <i class="ensurx-user"></i>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="input_feild">
                          <input type="email" class="form-control email" name="email" placeholder="E-mail">
                          <div class="icon">
                            <i class="ensurx-footer-mail"></i>
                          </div>
                        </div>
                      </div>

                      <div class="col-md-6">
                        <div class="input_feild">
                          <input type="text" class="form-control phone" name="telefon" placeholder="Telefon">
                          <div class="icon">
                            <i class="ensurx-call"></i>
                          </div>
                        </div>
                      </div>
                      
                      <div class="col-md-6">
                        <div class="input_feild">
                          <input type="text" class="form-control phone" name="konu" placeholder="Konu">
                          <div class="icon">
                            <i class="ensurx-call"></i>
                          </div>
                        </div>
                      </div>
                    
                      <div class="col-12">
                      <div class="textarea_feild">
                        <textarea placeholder="Mesaj" name="mesaj" class="form-control"></textarea>
                        <div class="icon">
                          <i class="ensurx-pen"></i>
                        </div>
                      </div>
                      </div>
                      <div class="col-md-12">
                        <button type="submit" name="iletisim-formu"class="common_btn">Gönder <i class="ensurx-arrow-right"></i></button>
                      </div>

                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      <section class="map_section">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12 p-0">
              <?=$googlemaps?>
            </div>
          </div>
        </div>
      </section>