<section class="life_insurance_section">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-lg-4">
                    <div class="insurance_left_main">
                        <div class="row gy-5">
                            <div class="col-md-12">
                                <div class="insurance_left_service">
                                    <h3>Diğer projeler</h3>
                                    <?php
                        $cek = $db->query("select * from projeler where durum='0' and not id='$id' order by sira asc")->fetchAll(PDO::FETCH_ASSOC);
						foreach($cek as $goster){
						?>
                                    <div class="left_service_wrapper">
                                        <h4><?=$goster["adi"]?></h4>
                                        <a href="<?=$goster["seo"]?>"><i class="ensurx-arrow-right"></i></a>
                                    </div>
                                    <?php }?>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
                <div class="col-md-12 col-lg-8">
                  <div class="insurance_right_main">
                    <div class="row">
                      <div class="col-md-12 mb-5">
                        <img src="resimler/<?=$projeler["resim"]?> " class="img-fluid" alt="">
                      </div>
                      <div class="col-md-12 mb-5">
                        <h2><?=$projeler["adi"]?></h2>
                        <p class="mt-5"><?=$projeler["aciklama"]?></p>
                      </div>

                    </div>
                  </div>
                </div>
            </div>
        </div>
     </section>