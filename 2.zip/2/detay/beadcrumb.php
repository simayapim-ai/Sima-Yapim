<section class="common_banner_section">

      <div class="common_banner_content">
         <div class="container">
          <div class="row justify-content-center">
              <div class="col-md-8">
                  <div class="common_banner_content">
                      <h1><?=$adi?></h1>
                      <p>Sima Yapım olarak sizler için en iyiyi hayal edip , gerçeğe dönüştürme gayesiyle var gücümüzle çalışmaktayız.</p>
                  </div>
              </div>
          </div>
         </div>
      </div>

      <div class="common_banner_bottom">
          <div class="container">
              <div class="row">
                  <div class="col-md-12">
                      <div class="common_banner_bottom_content">
                          <div class="text_home common_divider">
                              <div class="icon">
                                <i class="ensurx-home"></i>
                              </div>
                              <a href="index.php">Anasayfa</a>
                          </div>
                          <div class="text_home">
                             <?=$adi?>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </div>

      

</section>