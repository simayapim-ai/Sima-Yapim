<section class="project_section">
      <div class="container">

        <div class="row">
          <div class="col-lg-12">
            <div class="row projects_main gy-4">
 <?php
            $cek = $db->query("select * from projeler where durum='0' order by sira asc")->fetchAll(PDO::FETCH_ASSOC);
            foreach ($cek as $goster) {
            ?>
              <div class="col-md-6 col-lg-4 mix financial">
                <div class="project_item">

                  <img src="resimler/<?=$goster["resim"]?>" class="img-fluid" alt="">
                  <div class="project_bottom">
                    <div class="wrapper">
                      <div class="icon">
                        <a href="<?=$goster["seo"]?>"> <i class="ensurx-plus"></i> </a>
                      </div>
                    </div>
                     <h4><?=$goster["adi"]?></h4>
                  </div>
                  <div class="shape">
                    <img src="assets/images/bg/project-item-shape.png" class="img-fluid" alt="">
                  </div>

              </div>
              </div>

<?php } ?>
            </div>
          </div>
        </div>

        
      </div>
    </section>