<section class="blog_news_page">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-lg-8">
                    <div class="row gy-4">
                          <?php
                        $cek = $db->query("select * from haberler where durum='0' order by sira asc")->fetchAll(PDO::FETCH_ASSOC);
						foreach($cek as $goster){
						?>
                          <div class="col-sm-12 col-md-6">
                            <div class="blog_item">
              
                              <div class="blog_top">
                                <img src="resimler/<?=$goster["resim"]?>" class="img-fluid" alt="">
                              </div>
                              
                              <div class="blog_content">
                                <h3> <a href="<?=$goster["seo"]?>"><?=$goster["adi"]?></a> </h3>
                                <p><?=$goster["onaciklama"]?></p>
                                <a href="<?=$goster["seo"]?>" class="blog_btn">Devamını Oku <i class="ensurx-arrow-right"></i></a>
                              </div>
              
              
                            </div>
                          </div>
                          <?php }?>
                    </div>
                </div>
                <div class="col-md-12 col-lg-4">
                   <div class="blog_sidebar">
                    <div class="row gy-5">
                        <div class="col-md-12">
                            <div class="blog_page_post">
                                <h3>Popüler Gönderiler</h3>
                                <?php
                        $cek = $db->query("select * from haberler where durum='0' order by sira asc")->fetchAll(PDO::FETCH_ASSOC);
						foreach($cek as $goster){
						?>
                                <div class="post_item_wrapper">
                                        <img src="resimler/<?=$goster["resim"]?>" class="img-fluid" alt="">
                                    <div class="post_content">
                                        <a href="<?=$goster["seo"]?>"><?=$goster["adi"]?></a>
                                        <span><?=$goster["eklenme_tarihi"]?></span>
                                    </div>
                                </div>
                                <?php }?> 
                            </div>
                        </div>
                        
                    </div>
                   </div>
                </div>
            </div>
        </div>
    </section>